import cv2
import matplotlib.pyplot as plt

# Load the low-light image
image = cv2.imread('lowlight/l3.png')


# Increase brightness and contrast
alpha = 1.5 # Contrast control (1.0-3.0)
beta = 50  # Brightness control (0-100)
adjusted = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

# Convert the adjusted image to LAB color space
lab = cv2.cvtColor(adjusted, cv2.COLOR_BGR2LAB)

# Split the LAB image into separate channels
l, a, b = cv2.split(lab)

# Apply CLAHE to the L channel to enhance contrast
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
l_enhanced = clahe.apply(l)

# Merge the enhanced L channel with the original A and B channels
lab_enhanced = cv2.merge((l_enhanced, a, b))

# Convert the enhanced LAB image back to RGB color space
enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)

# Display the original and enhanced images
plt.subplot(2,2,1)
plt.imshow(image, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Original Image",fontsize = 10)

plt.subplot(2,2,2)
plt.imshow(enhanced, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Enhanced Image",fontsize = 10)
plt.subplots_adjust(left=0.2, bottom=0.05, right=0.8, top=0.95, wspace=0.1, hspace=0.1)
plt.show()
