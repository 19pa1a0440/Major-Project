import image_dehazer
import cv2
import matplotlib.pyplot as plt

img = cv2.imread('dehaze/d1.png',cv2.COLOR_BGR2HSV)
dehazed, HazeMap = image_dehazer.remove_haze(img,showHazeTransmissionMap=False)		# Remove Haze


# Display the original and dehazed images
plt.subplot(2,2,1),plt.imshow(img, cmap='gray'),plt.title('Hazed Image')
plt.xticks([]), plt.yticks([])
plt.subplot(2,2,2),plt.imshow(HazeMap, cmap='gray'),plt.title('Haze Map')
plt.xticks([]), plt.yticks([])
plt.subplot(2,2,3),plt.imshow(HazeMap, cmap='gray'),plt.title('Transmission Map')
plt.xticks([]), plt.yticks([])
plt.subplot(2,2,4),plt.imshow(dehazed, cmap='gray'),plt.title('Dehazed Image')
plt.xticks([]), plt.yticks([])
plt.show()
