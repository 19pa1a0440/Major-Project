import matplotlib.pyplot as plt
import numpy as np
import cv2

#reading the image
img = cv2.imread('contrast/c1.jpg')
#rgb image to hsv
hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
h, s, v = hsv_img[:,:,0], hsv_img[:,:,1], hsv_img[:,:,2]
clahe = cv2.createCLAHE(clipLimit = 4.0, tileGridSize = (20,20))
v = clahe.apply(v)
hsv_img = np.dstack((h,s,v))
rgb = cv2.cvtColor(hsv_img, cv2.COLOR_HSV2RGB)

#plotting images
plt.subplot(2,2,1)
plt.imshow(img, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Original Image",fontsize = 10)

plt.subplot(2,2,2)
plt.imshow(rgb, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Enhanced Image",fontsize = 10)
plt.subplots_adjust(left=0.2, bottom=0.05, right=0.8, top=0.95, wspace=0.1, hspace=0.1)
plt.show()