import cv2
import matplotlib.pyplot as plt

# Load the low-resolution image
img = cv2.imread('resolution/r2.png')

# Define the scale factor
scale = 1.5

# Upscale the image using bicubic interpolation
image_hr = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

# Apply image enhancement technique
image = cv2.detailEnhance(image_hr)

# Display the result
plt.subplot(2,2,1),plt.imshow(img, cmap=plt.cm.gray),plt.title('Original Image')
plt.xticks([]), plt.yticks([])
plt.subplot(2,2,2),plt.imshow(image, cmap=plt.cm.gray),plt.title('Restored Image')
plt.xticks([]), plt.yticks([])
plt.subplots_adjust(left=0.2, bottom=0.05, right=0.8, top=0.95, wspace=0.1, hspace=0.1)
plt.show()