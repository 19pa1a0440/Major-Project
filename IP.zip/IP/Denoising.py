import cv2
import numpy as np
from matplotlib import pyplot as plt
from skimage.restoration import (denoise_wavelet,estimate_sigma)
from skimage.util import random_noise
from skimage.metrics import peak_signal_noise_ratio
import skimage.io

img = skimage.io.imread("denoise/noise1.png")
img = skimage.img_as_float(img)

imgn = random_noise(img, mode='gaussian', mean=0, var=0.005, seed=None, clip=True)

sigma_est = estimate_sigma(imgn, channel_axis = -1, average_sigmas = True)
#Denoising using BayesShrink
img_bayes = denoise_wavelet(imgn, method = 'BayesShrink', sigma=sigma_est, wavelet_levels=2, wavelet='coif5', mode='soft', channel_axis=-1, convert2ycbcr=True,rescale_sigma=True)
#Denoising using NeighShrink
img_neigh = denoise_wavelet(imgn, method = 'VisuShrink', wavelet='db1', mode='soft', wavelet_levels=2, channel_axis = -1, convert2ycbcr = True, rescale_sigma = True)
#Denoising using VisuShrink
img_visushrink = denoise_wavelet(imgn, method = 'VisuShrink', mode = 'soft', sigma = sigma_est, wavelet_levels = 2, wavelet = 'coif5', channel_axis = -1, convert2ycbcr = True, rescale_sigma = True)


#Finding PSNR
psnr_noisy = peak_signal_noise_ratio(img,imgn)
psnr_neigh = peak_signal_noise_ratio(img,img_neigh)
psnr_visu = peak_signal_noise_ratio(img,img_visushrink)
psnr_bayes = peak_signal_noise_ratio(img,img_bayes)

#plotting images


plt.subplot(2,2,1)
plt.imshow(imgn, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Noisy Image",fontsize = 6)

plt.subplot(2,2,2)
plt.imshow(img_neigh, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Denoised Image Using Neigh Shrink",fontsize = 6)

plt.subplot(2,2,3)
plt.imshow(img_visushrink, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Denoised Image Using VisuShrink",fontsize = 6)

plt.subplot(2,2,4)
plt.imshow(img_bayes, cmap = plt.cm.gray)
plt.xticks([]), plt.yticks([])
plt.title("Denoised Image Using Bayes Shrink",fontsize = 6)

plt.show()

#printing psnr
print('PSNR [Original Vs Noisy]:',psnr_noisy)
print('PSNR [Original Vs Denoised(VisuShrink)]:',psnr_visu)
print('PSNR [Original Vs Denoised(Neigh Shrink)]:',psnr_neigh)
print("PSNR [Original Vs Denoised(Bayes Shrink)]:",psnr_bayes)