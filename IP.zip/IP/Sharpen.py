import cv2
import matplotlib.pyplot as plt

# Load the color image
img = cv2.imread("sharpen/s1.png")

# Apply the Gauusian Blur to the image
blur = cv2.GaussianBlur(img, (7,7), 2)
# Add the high-pass filter back to the original image to get the sharpened image
sharpened = cv2.addWeighted(img,4.5,blur,-3.5,0)

# Display the sharpened image
plt.subplot(2,2,1),plt.imshow(img, cmap = plt.cm.gray),plt.title('Original Image')
plt.xticks([]), plt.yticks([])
plt.subplot(2,2,2),plt.imshow(sharpened, cmap = plt.cm.gray),plt.title('Sharpened Image')
plt.xticks([]), plt.yticks([])
plt.subplots_adjust(left=0.2, bottom=0.05, right=0.8, top=0.95, wspace=0.1, hspace=0.1)
plt.show()

